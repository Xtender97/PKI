import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nalog',
  templateUrl: './nalog.component.html',
  styleUrls: ['./nalog.component.scss']
})
export class NalogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
